import React from "react";
import "./Project.css";


class Project extends React.Component {
  render() {
    return (
    	<a href={this.props.url} >
	    	<div className="project" style={{ backgroundImage: `url(${require("../Images/" + this.props.image)})` }}>
  		    <div className="project-text">
            <h1> {this.props.name} </h1>
  		    	<h2> {this.props.languages} </h2>
          </div>
	    	</div>
    	</a>
    );
  }
}

export default Project;