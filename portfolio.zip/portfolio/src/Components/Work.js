import React from "react";
import WorkData from "./Data.json";
import Project from "./Project.js"
import "./Work.css";


class Work extends React.Component {
	render() {
    	return (
			<div className="work">
				<h1 className="work-title">MY WORK</h1>
				<div className="projects">
					<Project name={WorkData.projects.boff.title} 
					languages={WorkData.projects.boff.languages}
					image={WorkData.projects.boff.image}
					url={WorkData.projects.boff.url}
					/>
					<Project name={WorkData.projects.candc.title} 
					languages={WorkData.projects.candc.languages}
					image={WorkData.projects.candc.image}
					url={WorkData.projects.candc.url}
					/>
				</div>
			</div>
		);
	}
}

export default Work;